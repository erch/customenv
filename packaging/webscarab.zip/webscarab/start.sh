#!/bin/bash
java -jar webscarab.jar
